<?php

//config
$admin = array("0000","0000"); // آیدی ادمین ها
$usernamebot = "@"; // یوزرنیم ربات
$channel = "asrnovin_ir"; // یوزرنیم کانال
$channelby = "@"; // یوزرنیم کانال گزارش
$web = "@bot"; // آدرس ربات
$sup = "@"; // یوزرنیم پشتیبانی
$far = "نوین نامبر"; // نام فارسی ربات

//api پنل ها
$apikey = "api"; //5sim
$apikey2 = "api"; //sms active


//database
$servername = "localhost";
$username = "user";
$password = 'pass';
$dbname = "user";

$tokenbot = 'tokenbot';

//مرچنت
$MerchantID = "00000";
?>